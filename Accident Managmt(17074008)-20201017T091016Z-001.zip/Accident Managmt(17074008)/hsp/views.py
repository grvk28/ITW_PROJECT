from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.db import connection

# Create your views here.


from django.http import HttpResponse


def index(request):
    # Construct a dictionary to pass to the template engine as its context.
    # Note the key boldmessage is the same as {{ boldmessage }} in the template!
    context_dict = {'boldmessage': "Crunchy, creamy, cookie, candy, cupcake!"}

    # Return a rendered response to send to the client.
    # We make use of the shortcut function to make our lives easier.
    # Note that the first parameter is the template we wish to use.
    return render(request, 'hsp/index.html', context=context_dict)
def about(request):

    return render(request, 'hsp/index.html')
def about1(request):

    return render(request, 'hsp/about1.html')


def new_view(request):
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM location")
    data = cursor.fetchall()
    return render(request,'hsp/new.html',{'data': data})

def about2(request):
    return render(request, 'hsp/about2.html')

def about3(request):

    return render(request, 'hsp/about3.html')

def about4(request):

    return render(request, 'hsp/about4.html')

def injury(request):


    return render(request, 'hsp/injury.html')

def injury1(request):

    return render(request, 'hsp/injury1.html')

def about5(request):

    return render(request, 'hsp/about5.html')

def about6(request):

    return render(request, 'hsp/about6.html')

def about7(request):

    return render(request, 'hsp/about7.html')

def search(request):

    return render(request, 'hsp/search.html')

def InjuryType(request):

    return render(request, 'hsp/about7.html')

def InjuryTypeAmputation(request):

    return render(request, 'hsp/Injury Type.Amputation and loss of limbs.html')

def InjuryTypeArm(request):

    return render(request, 'hsp/Injury Type.Arm Injury.html')

def InjuryTypeAsbestos(request):

    return render(request, 'hsp/Injury type.Asbestos.html')

def InjuryTypeBack(request):

    return render(request, 'hsp/Injury Type.Back Injury.html')

def InjuryTypeBroken(request):

    return render(request, 'hsp/Injury Type.Broken Bone and fractures.html')

def InjuryTypeBurn(request):

    return render(request, 'hsp/Injury Type.Burn injuries.html')

def InjuryTypeCarpel(request):

    return render(request, 'hsp/Injury Type.Carpel tunnel syndrome.html')

def InjuryTypeChemical(request):

    return render(request, 'hsp/Injury Type.Chemical injury.html')

def InjuryTypeEye(request):

    return render(request, 'hsp/Injury Type.Eye injury.html')

def InjuryTypeFatalaccident(request):

    return render(request, 'hsp/Injury Type.Fatal accident.html')

def InjuryTypeFatalinjuries(request):

    return render(request, 'hsp/Injury Type.Fatal injuries.html')

def InjuryTypeGroin(request):

    return render(request, 'hsp/Injury Type.Groin injury.html')

def InjuryTypeHand(request):

    return render(request, 'hsp/Injury Type.Hand injury.html')

def InjuryTypeHead(request):

    return render(request, 'hsp/Injury Type.Head and brain.html')

def InjuryTypeHeadand(request):

    return render(request, 'hsp/Injury Type.Head and brain injury.html')

def InjuryTypeHearing(request):

    return render(request, 'hsp/Injury Type.Hearing loss.html')

def InjuryTypeHip(request):

    return render(request, 'hsp/Injury Type.Hip Injury.html')

def InjuryTypeKnee(request):

    return render(request, 'hsp/Injury Type.Knee injury.html')

def InjuryTypeLeg(request):

    return render(request, 'hsp/Injury Type.Leg injury.html')

def InjuryTypeNeck(request):

    return render(request, 'hsp/Injury Type.Neck injury.html')

def InjuryTypeSerious(request):
    return render(request, 'hsp/Injury Type.Serious Injury.html')

def InjuryTypeWhiplash(request):
    return render(request, 'hsp/Injury Type.Whiplash.html')

def InjuryTypeRepetitive(request):
    return render(request, 'hsp/Injury Types.Repetitive strain injury.html')

def AccidentTypeBicycle(request):
    return render(request, 'hsp/Accident Type.Bicycle Accident.html')

def AccidentTypeCar(request):
    return render(request, 'hsp/Accident Type.Car accident.html')

def AccidentTypecarbon(request):
    return render(request, 'hsp/Accident Type.carbon monoxide.html')

def AccidentTypecarer(request):
    return render(request, 'hsp/Accident Type.carer.html')

def AccidentTypeDefective(request):
    return render(request, 'hsp/Accident Type.Defective product.html')

def AccidentTypeDog(request):
   return render(request, 'hsp/Accident Type.Dog bites.html')

def AccidentTypeFactory(request):
    return render(request, 'hsp/Accident Type.Factory.html')

def AccidentTypeFarm(request):
    return render(request, 'hsp/Accident Type.Farm.html')

def AccidentTypeFatal(request):
    return render(request, 'hsp/Accident Type.Fatal road accidents.html')

def AccidentTypeHoliday(request):
    return render(request, 'hsp/Accident Type.Holiday.html')

def AccidentTypeIndustrial(request):
    return render(request, 'hsp/Accident Type.Industrial.html')

def AccidentTypeMachinery(request):
    return render(request, 'hsp/Accident Type.Machinery.html')

def AccidentTypeMilitary(request):
    return render(request, 'hsp/Accident Type.Military.html')

def AccidentTypeMotorcycle(request):
    return render(request, 'hsp/Accident Type.Motorcycle.html')

def AccidentTypeNeedlestick(request):
    return render(request, 'hsp/Accident Type.Needlestick.html')

def AccidentTypeOffice(request):
    return render(request, 'hsp/Accident Type.Office.html')

def AccidentTypePassenger(request):
    return render(request, 'hsp/Accident Type.Passenger.html')

def AccidentTypePavement(request):
    return render(request, 'hsp/Accident Type.pavement.html')

def AccidentTypePublic(request):
    return render(request, 'hsp/Accident Type.Public.html')

def AccidentTypeShopping(request):
    return render(request, 'hsp/Accident Type.Shopping.html')

def AccidentTypesport(request):
   return render(request, 'hsp/Accident Type.sport.html')

def AccidentTypeSupermarket(request):
    return render(request, 'hsp/Accident Type.Supermarket.html')

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('templates:list')
        else:
          form = UserCreationForm()
          return render(request, 'hsp/about4.html',{'form':form})
def newsfeed(request): #Execution of syndcation
    return render(request,'hsp/rss.html',{})
