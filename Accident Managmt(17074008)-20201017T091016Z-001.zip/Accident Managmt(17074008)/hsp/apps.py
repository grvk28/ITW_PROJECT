from django.apps import AppConfig


class HspConfig(AppConfig):
    name = 'hsp'
