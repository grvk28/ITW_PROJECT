from django.contrib import admin
from hsp.models import Category, Page

admin.site.register(Category)
admin.site.register(Page)


# Register your models here.
